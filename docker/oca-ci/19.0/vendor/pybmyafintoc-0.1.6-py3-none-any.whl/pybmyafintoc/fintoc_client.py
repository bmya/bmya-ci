"""Cliente Fintoc para movimientos bancarios (Chile).

Wrapper delgado sobre el SDK oficial (`fintoc`) + lógica de negocio propia.
Librería standalone sin dependencias de Odoo.
"""
import logging
import re
from datetime import datetime, timezone

from fintoc import Fintoc
import fintoc.paginator as _fintoc_paginator
import httpx

_logger = logging.getLogger(__name__)

PATTERN_RUT = r'\b\d{1,2}\.\d{3}\.\d{3}-[\dKk]\b'

# --- Parche: 2 bugs en fintoc-python (paginator.py) ---
# 1. `paginator.request()` usa `params={}` como default y lo pasa explícitamente
#    a httpx.Request(). Confirmado con un test aislado: httpx.Request(url_con_query,
#    params={}) DESCARTA el query string ya presente en `url`, mientras que
#    params=None lo preserva. Esto rompe la paginación en TODOS los endpoints
#    .list() del SDK a partir de la página 2 (probado con /v1/accounts/{id}/movements,
#    400 Bad Request al perder link_token). Bug del lado del SDK, no de la API de
#    Fintoc. Reportar en https://github.com/fintoc-com/fintoc-python/issues.
# 2. [Detectado en producción, jul-2026] La primera versión de ESTE MISMO parche
#    armaba el ``httpx.Request`` a mano y lo mandaba con ``client.send()``. Eso
#    rompe TODA la paginación (no solo desde la página 2): ``client.send()`` NO
#    resuelve `url` contra ``client.base_url`` ni fusiona los headers default del
#    cliente (Authorization incluido) -- eso solo lo hace ``client.build_request()``.
#    Confirmado con un servidor HTTP real: ``client.send(httpx.Request("get", "/accounts"))``
#    truena con ``httpx.UnsupportedProtocol`` (URL sin scheme/host), sea la ruta
#    relativa (página 1) o absoluta con query propio (página 2+, tomada del header
#    Link) -- ``build_request()`` resuelve ambos casos correctamente vía
#    ``Client._merge_url()``.
def _patched_paginator_request(client, url, params=None, headers={}):
    _request = client.build_request("get", url, params=params, headers=headers)
    response = client.send(_request)
    response.raise_for_status()
    parsed = _fintoc_paginator.parse_link_headers(response.headers.get("link"))
    next_ = parsed and parsed.get("next")
    return {"next": next_, "elements": response.json()}


_fintoc_paginator.request = _patched_paginator_request
# --- Fin del parche ---


def _to_fintoc_utc(dt):
    """Normaliza un datetime (naive o con tz) al formato UTC 'Z' que exige
    la API de Fintoc para `since`/`until`.

    Si `dt` es naive se asume que ya representa UTC (mismo criterio que
    `parse_fintoc_date`, que parsea las fechas de Fintoc sin adjuntar
    tzinfo). Si trae tzinfo (p.ej. America/Santiago) se convierte a UTC
    antes de formatear: nunca concatenar 'Z' a un isoformat() que ya trae
    un offset numérico, porque produce un timestamp inválido del tipo
    '2026-07-01T00:00:00-04:00Z' que Fintoc rechaza con 400 Bad Request.
    """
    if dt.tzinfo is not None:
        dt = dt.astimezone(timezone.utc)
    return dt.strftime('%Y-%m-%dT%H:%M:%SZ')


class FintocAPIError(Exception):
    """``status_code`` (HTTP, puede ser None) permite a los callers distinguir
    p.ej. 404/403 (recurso ya no accesible) de otros errores (5xx, timeout)
    sin tener que parsear el mensaje. Ver delete_fintoc_link en
    company_service_endpoints.py, que verifica el delete con get_link_status()
    en vez de confiar ciegamente en un 404."""

    def __init__(self, message, status_code=None):
        super().__init__(message)
        self.status_code = status_code


class FintocClient:

    def __init__(self, secret_api_key, link_token=None):
        # Nunca loguear el link_token: es un credencial (autentica contra
        # Fintoc como ese link específico), se guarda encriptado en Mongo, y
        # se detectó en producción que este log lo imprimía en texto plano.
        _logger.info('[fintoc_client] FintocClient init (link_token_provided=%s)', bool(link_token))
        self.client = Fintoc(secret_api_key)
        self.link_token = link_token

    @property
    def _links_path(self):
        """Ruta base de 'links' TAL COMO la registró el SDK instalado (nunca
        hardcodear '/v1/links'): la convención de ``base_url`` cambió entre
        versiones del SDK -- antes de fintoc==2.10.0, ``base_url`` ya incluía
        '/v1' y los managers registraban rutas sin él (p.ej. '/links'); desde
        la 2.10.0, ``base_url`` no incluye '/v1' y los managers registran
        '/v1/links'. Leer ``self.client.links._path`` (el manager público)
        evita duplicar el prefijo sea cual sea la versión resuelta en el
        entorno (se vio en producción: '/v1/v1/links/...' -> 404 permanente
        en pausar/verificar/eliminar links)."""
        return self.client.links._path  # noqa: SLF001 — ver docstring.

    @property
    def _accounts_path(self):
        """Ruta base de 'accounts', derivada de ``_links_path`` (mismo motivo:
        nunca hardcodear '/v1/accounts'). A diferencia de links, acá NO se
        puede leer ``self.client.accounts._path`` porque ese manager no
        existe en SDKs viejos (confirmado en producción: fintoc==2.4.1 no
        registra ``self.accounts`` en absoluto -> AttributeError en cada
        sincronización de movimientos). Se deriva reemplazando el último
        segmento de ``_links_path`` en su lugar, así funciona con o sin ese
        manager."""
        return self._links_path.rsplit("/", 1)[0] + "/accounts"

    def get_accounts(self):
        """Retorna lista de cuentas (dicts) asociadas al link_token.

        Usa el cliente de bajo nivel (no el manager ``.accounts.list()``,
        que no existe en todas las versiones del SDK -- ver ``_accounts_path``)
        con paginación nativa: ``Client.request(paginated=True)`` ya devuelve
        los elementos crudos (dicts) de cada página vía ``fintoc.paginator``
        (parcheado arriba), sin necesidad de instanciar objetos del SDK.
        """
        _logger.info('[fintoc_client] get_accounts start')
        try:
            accounts = list(self.client._client.request(
                self._accounts_path, paginated=True, params={"link_token": self.link_token},
            ))
        except httpx.HTTPStatusError as error:
            _logger.error('[fintoc_client] get_accounts error: %s', error)
            raise FintocAPIError(
                'Error al obtener cuentas: %s' % error, status_code=error.response.status_code,
            ) from error
        _logger.info('[fintoc_client] get_accounts done: %s cuentas', len(accounts))
        return accounts

    def get_movements(self, account_id, since, until, limit=None):
        """Retorna lista de movimientos (dicts) ordenados por post_date ascendente.

        Trae siempre el rango completo since/until (paginado internamente por
        el SDK) y recién después ordena y recorta. Esto evita perder datos:
        si se cortara la paginación antes de completarla, no hay garantía de
        que la API devuelva los movimientos en orden cronológico, y un
        `last_sync` avanzado sobre un conjunto arbitrario dejaría movimientos
        antiguos inalcanzables en sincronizaciones futuras.

        Igual que ``get_accounts()``: cliente de bajo nivel en vez del manager
        ``.accounts.movements.list()`` (ver ``_accounts_path``).

        :param limit: si se especifica, recorta el resultado a los `limit`
            movimientos más antiguos del rango ya ordenado.
        """
        _logger.info('[fintoc_client] get_movements start account_id=%s since=%s until=%s limit=%s',
                      account_id, since, until, limit)
        try:
            movements = list(self.client._client.request(
                f"{self._accounts_path}/{account_id}/movements",
                paginated=True,
                params={
                    "link_token": self.link_token,
                    "since": _to_fintoc_utc(since),
                    "until": _to_fintoc_utc(until),
                },
            ))
        except httpx.HTTPStatusError as error:
            _logger.error('[fintoc_client] get_movements error: %s', error)
            raise FintocAPIError(
                'Error al obtener movimientos: %s' % error, status_code=error.response.status_code,
            ) from error

        _logger.info('[fintoc_client] get_movements fetched %s movimientos (sin recortar)', len(movements))
        movements.sort(key=lambda m: m.get('post_date') or '')
        if limit:
            movements = movements[:limit]
            _logger.info('[fintoc_client] get_movements recortado a limit=%s -> %s movimientos', limit, len(movements))
        return movements

    def set_link_active(self, active):
        """Activa o pausa el link completo en Fintoc (PATCH /v1/links/{link_token}).

        Afecta a TODAS las cuentas del link (Fintoc cobra/sincroniza a nivel
        de link, no de cuenta individual). Usa el cliente interno de bajo
        nivel (no el manager .links.update()) para no perder el status code
        real ante errores -- can_raise_fintoc_error lo descarta.
        """
        _logger.info('[fintoc_client] set_link_active link_token=%s active=%s', self.link_token, active)
        try:
            return self.client._client.request(
                f"{self._links_path}/{self.link_token}", method="patch", json={"active": bool(active)},
            )
        except httpx.HTTPStatusError as error:
            raise FintocAPIError(
                'Error al actualizar el link: %s' % error, status_code=error.response.status_code,
            ) from error

    def get_link_status(self):
        """Consulta el estado del link (GET /v1/links/{link_token}).

        Retorna el dict crudo de Fintoc: incluye 'status' (active/
        login_required/inactive) y 'active' (bool de facturación).
        """
        try:
            return self.client._client.request(f"{self._links_path}/{self.link_token}", method="get")
        except httpx.HTTPStatusError as error:
            raise FintocAPIError(
                'Error al consultar el estado del link: %s' % error, status_code=error.response.status_code,
            ) from error

    def delete_link(self, link_id):
        """Elimina el link en Fintoc (DELETE /v1/links/{id}).

        A diferencia de get_link_status()/set_link_active() (que usan
        link_token), este endpoint usa el ID CORTO del link
        (``fintoc_links.fintoc_link_external_id``, ej.
        'link_52NXJAi0vyDDLn4v'), NO el link_token completo. Confirmado
        empíricamente contra la API real de Fintoc: DELETE con el link_token
        devuelve 404 "missing_resource" (param "id") aunque el link exista y
        siga activo (GET con el mismo token lo confirma vivo); DELETE con el
        id corto devuelve 204 y el link efectivamente desaparece (GET
        posterior con el token pasa a 403 invalid_link_token). Esto
        contradice la guía del SDK oficial de Fintoc ("para obtener,
        actualizar o eliminar un link se necesita el link_token") -- al
        menos para DELETE, es una inconsistencia de la propia API/
        documentación de Fintoc, no un bug de esta librería.

        Idempotente: un 404 se trata como 'ya estaba eliminado', no como error.
        """
        try:
            self.client._client.request(f"{self._links_path}/{link_id}", method="delete")
            return {"deleted": True, "already_gone": False}
        except httpx.HTTPStatusError as error:
            if error.response.status_code == 404:
                return {"deleted": True, "already_gone": True}
            raise FintocAPIError(
                'Error al eliminar el link: %s' % error, status_code=error.response.status_code,
            ) from error


def normalize_account_number(account_number):
    return account_number and re.sub(r'\W+', '', account_number).upper()


def build_account_index(accounts):
    """accounts: lista de dicts de get_accounts(). Retorna {numero_normalizado: id}"""
    return {normalize_account_number(a.get('number')): a.get('id') for a in accounts}


def parse_fintoc_date(date_str):
    return datetime.strptime(date_str, '%Y-%m-%dT%H:%M:%SZ')


def get_counterpart_account(statement_line):
    for key in ('sender_account', 'recipient_account'):
        data = statement_line.get(key, {})
        if data:
            return data
    return None


def build_payment_ref(statement_line):
    description = statement_line.get('description', '')
    amount = statement_line.get('amount', 0)
    sender = statement_line.get('sender_account')
    recipient = statement_line.get('recipient_account')

    if amount > 0 and sender:
        holder = sender.get('holder_name', '')
        institution = (sender.get('institution') or {}).get('name', '')
        if holder:
            if institution:
                return "%s - De: %s (%s)" % (description, holder, institution)
            return "%s - De: %s" % (description, holder)

    if amount < 0 and recipient:
        holder = recipient.get('holder_name', '')
        institution = (recipient.get('institution') or {}).get('name', '')
        if holder:
            if institution:
                return "%s - A: %s (%s)" % (description, holder, institution)
            return "%s - A: %s" % (description, holder)

    ref = statement_line.get('reference_id') or statement_line.get('document_number')
    if ref and ref not in description:
        return "%s (ref: %s)" % (description, ref)

    return description


def extract_rut(text):
    """RUTs chilenos encontrados en el texto (formato XX.XXX.XXX-X)."""
    return re.findall(PATTERN_RUT, text or '')


def normalize_rut(rut):
    return rut.replace('.', '')


